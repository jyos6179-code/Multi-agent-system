"""
agents.tracker
==============
Consumes raw, noisy sensor readings and turns them into a smoothed
position + velocity estimate. This is deliberately the "perception"
layer: swap the body of `handle()` for a Kalman filter, a vision model
call, or a DB poll, and nothing downstream (Predictor/Commander) needs
to change since they only care about the TrackEstimate contract.
"""

from __future__ import annotations

import logging

from core.message_bus import Message
from core.types import SensorReading, TrackEstimate, Vector2

from .base_agent import BaseAgent

logger = logging.getLogger(__name__)

# Exponential smoothing factor: higher = trust new readings more.
_ALPHA = 0.6


class Tracker(BaseAgent):
    subscribes_to = ("sensor/raw",)

    def __init__(self, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        self._last_position: Vector2 | None = None
        self._last_t: float | None = None

    async def handle(self, message: Message) -> None:
        reading: SensorReading = message.payload

        if self._last_position is None:
            smoothed = reading.position
            velocity = Vector2(0.0, 0.0)
        else:
            smoothed = Vector2(
                x=_ALPHA * reading.position.x + (1 - _ALPHA) * self._last_position.x,
                y=_ALPHA * reading.position.y + (1 - _ALPHA) * self._last_position.y,
            )
            dt = max(reading.t - (self._last_t or reading.t), 1e-6)
            velocity = Vector2(
                x=(smoothed.x - self._last_position.x) / dt,
                y=(smoothed.y - self._last_position.y) / dt,
            )

        self._last_position = smoothed
        self._last_t = reading.t

        confidence = max(0.0, 1.0 - reading.noise_std)
        estimate = TrackEstimate(position=smoothed, velocity=velocity, confidence=confidence)

        await self.blackboard.set("last_track", estimate)
        await self.publish("track/update", estimate)
        logger.debug("[%s] track=%s", self.name, estimate)
