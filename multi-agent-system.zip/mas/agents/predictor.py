"""
agents.predictor
=================
Consumes TrackEstimates from the Tracker and forecasts where the target
will be `horizon_s` seconds from now. Uses the shared `extrapolate` tool
from core.tools rather than reimplementing the math -- this is the
"share tools" requirement in action: Tracker could call the same tool
for its own short-horizon smoothing if you wanted.

Swap linear extrapolation for an actual ML model (LSTM, transformer,
physics sim) by replacing the body of `handle()`; the Forecast contract
is all Commander depends on.
"""

from __future__ import annotations

import logging

from core.message_bus import Message
from core.types import Forecast, TrackEstimate

from .base_agent import BaseAgent

logger = logging.getLogger(__name__)

_HORIZON_S = 2.0


class Predictor(BaseAgent):
    subscribes_to = ("track/update",)

    async def handle(self, message: Message) -> None:
        estimate: TrackEstimate = message.payload

        predicted_position = await self.tools.call(
            "extrapolate", estimate.position, estimate.velocity, _HORIZON_S
        )

        forecast = Forecast(horizon_s=_HORIZON_S, predicted_position=predicted_position)

        await self.blackboard.set("last_forecast", forecast)
        await self.publish("predict/forecast", forecast)
        logger.debug("[%s] forecast=%s", self.name, forecast)
