"""
agents.base_agent
==================
Every specialized agent (Tracker, Predictor, Commander) extends this.
It standardizes:
  - how an agent subscribes to and publishes on the shared MessageBus
  - how it reads/writes shared state on the Blackboard
  - how it calls shared Tools
  - a uniform async run loop + graceful shutdown

This is the piece you rarely need to touch when adapting the system to
a new [task] -- you mostly write new subclasses of BaseAgent.
"""

from __future__ import annotations

import abc
import asyncio
import logging

from core.blackboard import Blackboard
from core.message_bus import Message, MessageBus
from core.tools import ToolRegistry

logger = logging.getLogger(__name__)


class BaseAgent(abc.ABC):
    #: topics this agent listens to; override in subclasses
    subscribes_to: tuple[str, ...] = ()

    def __init__(
        self,
        name: str,
        bus: MessageBus,
        blackboard: Blackboard,
        tools: ToolRegistry,
    ) -> None:
        self.name = name
        self.bus = bus
        self.blackboard = blackboard
        self.tools = tools
        self._stopped = asyncio.Event()

    async def publish(self, topic: str, payload: object) -> None:
        await self.bus.publish(Message(topic=topic, sender=self.name, payload=payload))

    def stop(self) -> None:
        self._stopped.set()

    @abc.abstractmethod
    async def handle(self, message: Message) -> None:
        """React to one incoming message. Implemented by each agent."""
        raise NotImplementedError

    async def run(self) -> None:
        """
        Main loop: fan-in every subscribed topic and dispatch to `handle`.
        Agents run concurrently as independent asyncio tasks -- there is
        no central orchestrator deciding turn order.
        """
        subscriptions = [self.bus.subscribe(topic) for topic in self.subscribes_to]
        queues = [asyncio.ensure_future(sub.get()) for sub in subscriptions]

        logger.info("[%s] online, listening on %s", self.name, self.subscribes_to)

        while not self._stopped.is_set():
            if not queues:
                await asyncio.sleep(0.05)
                continue

            done, _ = await asyncio.wait(
                queues, timeout=0.2, return_when=asyncio.FIRST_COMPLETED
            )
            for finished in done:
                message: Message = finished.result()
                idx = queues.index(finished)
                await self.handle(message)
                queues[idx] = asyncio.ensure_future(subscriptions[idx].get())

        for q in queues:
            q.cancel()
        logger.info("[%s] shutting down", self.name)
