"""
agents.commander
=================
The decision-making / actuation layer. Consumes Forecasts from the
Predictor, decides on an action (here: steer toward the predicted
intercept point), and is the agent responsible for declaring the
mission solved -- it's the only agent with a notion of "goal".

This is where you'd plug in an LLM call for higher-level reasoning
(e.g. "should we intercept, evade, or ignore?") via the shared
ToolRegistry -- register an `llm_reason` tool in main.py and call
`await self.tools.call("llm_reason", prompt=...)` here.
"""

from __future__ import annotations

import logging

from core.message_bus import Message
from core.types import Command, Forecast, Vector2

from .base_agent import BaseAgent

logger = logging.getLogger(__name__)

_INTERCEPT_RADIUS = 5.0
_MAX_THRUST = 8.0


class Commander(BaseAgent):
    subscribes_to = ("predict/forecast",)

    def __init__(self, *args, own_position: Vector2, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        self.position = own_position

    async def handle(self, message: Message) -> None:
        forecast: Forecast = message.payload

        distance = await self.tools.call("distance", self.position, forecast.predicted_position)

        if distance <= _INTERCEPT_RADIUS:
            await self.blackboard.set("mission_solved", True)
            await self.publish(
                "command/action",
                Command(
                    action="INTERCEPT",
                    target_position=forecast.predicted_position,
                    thrust=Vector2(0.0, 0.0),
                    reason=f"within intercept radius ({distance:.2f} <= {_INTERCEPT_RADIUS})",
                ),
            )
            await self.publish("system/stop", {"reason": "mission_solved"})
            logger.info("[%s] TARGET INTERCEPTED at distance %.2f", self.name, distance)
            return

        direction = forecast.predicted_position - self.position
        norm = max((direction.x**2 + direction.y**2) ** 0.5, 1e-6)
        thrust = Vector2(
            x=await self.tools.call("clamp", direction.x / norm * _MAX_THRUST, -_MAX_THRUST, _MAX_THRUST),
            y=await self.tools.call("clamp", direction.y / norm * _MAX_THRUST, -_MAX_THRUST, _MAX_THRUST),
        )
        self.position = self.position + thrust.scale(0.1)  # cheap kinematic step

        command = Command(
            action="PURSUE",
            target_position=forecast.predicted_position,
            thrust=thrust,
            reason=f"closing distance ({distance:.2f} > {_INTERCEPT_RADIUS})",
        )
        await self.publish("command/action", command)
        logger.debug("[%s] command=%s", self.name, command)
