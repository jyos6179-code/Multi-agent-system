"""
core.tools
==========
A shared tool registry. Any agent can register a tool and any agent can
call one registered by another -- this is the "share tools" requirement:
Tracker, Predictor, and Commander all pull from the same ToolRegistry
instance instead of each hand-rolling their own math or duplicating an
LLM/client wrapper.

To wire in a real LLM call (e.g. for the Commander to reason about
ambiguous situations), register an async tool here that calls your
model client, then `await tools.call("llm_reason", prompt=...)` from
any agent. Nothing else in the framework needs to change.
"""

from __future__ import annotations

import math
from typing import Any, Awaitable, Callable

from .types import Vector2

ToolFn = Callable[..., Any]


class ToolRegistry:
    def __init__(self) -> None:
        self._tools: dict[str, ToolFn] = {}

    def register(self, name: str, fn: ToolFn) -> None:
        if name in self._tools:
            raise ValueError(f"Tool '{name}' already registered")
        self._tools[name] = fn

    def __contains__(self, name: str) -> bool:
        return name in self._tools

    async def call(self, name: str, /, *args: Any, **kwargs: Any) -> Any:
        if name not in self._tools:
            raise KeyError(f"Unknown tool: {name}")
        fn = self._tools[name]
        result = fn(*args, **kwargs)
        if isinstance(result, Awaitable):
            return await result
        return result


# ---- Built-in shared tools -------------------------------------------------

def euclidean_distance(a: Vector2, b: Vector2) -> float:
    return math.hypot(a.x - b.x, a.y - b.y)


def linear_extrapolate(position: Vector2, velocity: Vector2, horizon_s: float) -> Vector2:
    return position + velocity.scale(horizon_s)


def clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


def build_default_registry() -> ToolRegistry:
    """Factory so `main.py` can construct one registry shared by all agents."""
    registry = ToolRegistry()
    registry.register("distance", euclidean_distance)
    registry.register("extrapolate", linear_extrapolate)
    registry.register("clamp", clamp)
    return registry
