"""
core.types
==========
Shared, dependency-free data structures passed between agents on the bus.
Keeping these as plain dataclasses (not framework-specific objects) means
you can serialize them to JSON, log them, or swap the transport (asyncio
queue -> Redis -> Kafka) without touching agent logic.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from time import time
from typing import Any


@dataclass(frozen=True)
class Vector2:
    x: float
    y: float

    def __add__(self, other: "Vector2") -> "Vector2":
        return Vector2(self.x + other.x, self.y + other.y)

    def __sub__(self, other: "Vector2") -> "Vector2":
        return Vector2(self.x - other.x, self.y - other.y)

    def scale(self, k: float) -> "Vector2":
        return Vector2(self.x * k, self.y * k)


@dataclass
class Message:
    """Envelope for everything sent over the MessageBus."""

    topic: str
    sender: str
    payload: Any
    timestamp: float = field(default_factory=time)


@dataclass
class SensorReading:
    position: Vector2
    noise_std: float
    t: float = field(default_factory=time)


@dataclass
class TrackEstimate:
    position: Vector2
    velocity: Vector2
    confidence: float
    t: float = field(default_factory=time)


@dataclass
class Forecast:
    horizon_s: float
    predicted_position: Vector2
    t: float = field(default_factory=time)


@dataclass
class Command:
    action: str
    target_position: Vector2
    thrust: Vector2
    reason: str
    t: float = field(default_factory=time)
