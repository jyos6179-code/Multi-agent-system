"""
core.message_bus
=================
Minimal async pub/sub bus. Agents never call each other directly -- they
publish to a topic and subscribe to topics they care about. This keeps
agents decoupled: you can add a 4th agent (e.g. a Logger or an Auditor)
without changing Tracker/Predictor/Commander at all.

Swap this implementation for Redis Pub/Sub, NATS, or Kafka in production
without changing any agent code, since agents only depend on the
`publish` / `subscribe` interface below.
"""

from __future__ import annotations

import asyncio
from collections import defaultdict
from typing import AsyncIterator

from .types import Message


class MessageBus:
    def __init__(self) -> None:
        self._subscribers: dict[str, list[asyncio.Queue[Message]]] = defaultdict(list)
        self._log: list[Message] = []

    def subscribe(self, topic: str) -> "Subscription":
        queue: asyncio.Queue[Message] = asyncio.Queue()
        self._subscribers[topic].append(queue)
        return Subscription(topic, queue)

    async def publish(self, message: Message) -> None:
        self._log.append(message)
        for queue in self._subscribers.get(message.topic, []):
            await queue.put(message)

    @property
    def history(self) -> list[Message]:
        return list(self._log)


class Subscription:
    """Async-iterable handle returned by MessageBus.subscribe()."""

    def __init__(self, topic: str, queue: "asyncio.Queue[Message]") -> None:
        self.topic = topic
        self._queue = queue

    async def __aiter__(self) -> AsyncIterator[Message]:
        while True:
            yield await self._queue.get()

    async def get(self) -> Message:
        return await self._queue.get()
