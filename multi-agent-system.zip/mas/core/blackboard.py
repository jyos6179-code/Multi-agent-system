"""
core.blackboard
================
A small thread/task-safe shared memory ("blackboard" pattern) for state
that isn't naturally a message -- e.g. mission status, shared config,
or the last-known value of something any agent might need to peek at
without subscribing to a whole topic history.

Prefer the MessageBus for anything event-like ("a new reading arrived").
Use the Blackboard for anything state-like ("are we done yet?").
"""

from __future__ import annotations

import asyncio
from typing import Any


class Blackboard:
    def __init__(self) -> None:
        self._state: dict[str, Any] = {}
        self._lock = asyncio.Lock()

    async def set(self, key: str, value: Any) -> None:
        async with self._lock:
            self._state[key] = value

    async def get(self, key: str, default: Any = None) -> Any:
        async with self._lock:
            return self._state.get(key, default)

    async def snapshot(self) -> dict[str, Any]:
        async with self._lock:
            return dict(self._state)
